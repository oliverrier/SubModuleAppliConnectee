/**
 * 
 */
package laboCrudJavaFx.repository.bdd;

import java.util.List;

import laboCrudJavaFx.model.Poney;
import laboCrudJavaFx.repository.Repository;

/**
 * @author sebbo
 *
 */
public class PoneyRepository implements Repository<Poney> {

	@Override
	public void addOrUpdate(Poney item) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<Poney> getAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Poney get(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void remove(Poney item) {
		// TODO Auto-generated method stub

	}

}
